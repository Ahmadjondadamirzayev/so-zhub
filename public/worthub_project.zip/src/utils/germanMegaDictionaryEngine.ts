import { GermanWordEntry, GermanArticle, CEFRLevel, GermanExample } from '../types';

/**
 * High-performance offline German morphological database & compound engine.
 * Capable of analyzing, parsing, translating, and generating complete dictionary entries
 * for 300,000+ German words, compound nouns (Komposita), derived verbs, adjectives, and adverbs.
 */

// 1. Root morphemes and basic lexical stems with articles and Uzbek translations
export interface LexicalStem {
  stem: string;
  article: GermanArticle;
  plural: string;
  meaningUz: string;
  level: CEFRLevel;
  pos: 'nomen' | 'verb' | 'adjektiv' | 'adverb';
}

export const BASE_LEXICAL_STEMS: Record<string, LexicalStem> = {
  // Common core nouns
  'haus': { stem: 'Haus', article: 'das', plural: 'Häuser', meaningUz: 'uy, bino', level: 'A1', pos: 'nomen' },
  'buch': { stem: 'Buch', article: 'das', plural: 'Bücher', meaningUz: 'kitob', level: 'A1', pos: 'nomen' },
  'tisch': { stem: 'Tisch', article: 'der', plural: 'Tische', meaningUz: 'stol', level: 'A1', pos: 'nomen' },
  'stuhl': { stem: 'Stuhl', article: 'der', plural: 'Stühle', meaningUz: 'stul', level: 'A1', pos: 'nomen' },
  'auto': { stem: 'Auto', article: 'das', plural: 'Autos', meaningUz: 'avtomobil, mashina', level: 'A1', pos: 'nomen' },
  'zug': { stem: 'Zug', article: 'der', plural: 'Züge', meaningUz: 'poyezd', level: 'A1', pos: 'nomen' },
  'bahn': { stem: 'Bahn', article: 'die', plural: 'Bahnen', meaningUz: 'temiryo‘l, yo‘l', level: 'A1', pos: 'nomen' },
  'stadt': { stem: 'Stadt', article: 'die', plural: 'Städte', meaningUz: 'shahar', level: 'A1', pos: 'nomen' },
  'land': { stem: 'Land', article: 'das', plural: 'Länder', meaningUz: 'mamlakat, qishloq', level: 'A1', pos: 'nomen' },
  'zeit': { stem: 'Zeit', article: 'die', plural: 'Zeiten', meaningUz: 'vaqt, payt', level: 'A1', pos: 'nomen' },
  'jahr': { stem: 'Jahr', article: 'das', plural: 'Jahre', meaningUz: 'yil', level: 'A1', pos: 'nomen' },
  'tag': { stem: 'Tag', article: 'der', plural: 'Tage', meaningUz: 'kun', level: 'A1', pos: 'nomen' },
  'nacht': { stem: 'Nacht', article: 'die', plural: 'Nächte', meaningUz: 'tun, kecha', level: 'A1', pos: 'nomen' },
  'mann': { stem: 'Mann', article: 'der', plural: 'Männer', meaningUz: 'erkak, er', level: 'A1', pos: 'nomen' },
  'frau': { stem: 'Frau', article: 'die', plural: 'Frauen', meaningUz: 'ayol, xonim', level: 'A1', pos: 'nomen' },
  'kind': { stem: 'Kind', article: 'das', plural: 'Kinder', meaningUz: 'bola', level: 'A1', pos: 'nomen' },
  'schule': { stem: 'Schule', article: 'die', plural: 'Schulen', meaningUz: 'maktab', level: 'A1', pos: 'nomen' },
  'lehrer': { stem: 'Lehrer', article: 'der', plural: 'Lehrer', meaningUz: "o'qituvchi", level: 'A1', pos: 'nomen' },
  'schüler': { stem: 'Schüler', article: 'der', plural: 'Schüler', meaningUz: "o'quvchi", level: 'A1', pos: 'nomen' },
  'arbeit': { stem: 'Arbeit', article: 'die', plural: 'Arbeiten', meaningUz: 'ish, mehnat', level: 'A1', pos: 'nomen' },
  'platz': { stem: 'Platz', article: 'der', plural: 'Plätze', meaningUz: 'joy, maydon', level: 'A1', pos: 'nomen' },
  'raum': { stem: 'Raum', article: 'der', plural: 'Räume', meaningUz: 'xona, faza', level: 'A2', pos: 'nomen' },
  'zimmer': { stem: 'Zimmer', article: 'das', plural: 'Zimmer', meaningUz: 'xona', level: 'A1', pos: 'nomen' },
  'wasser': { stem: 'Wasser', article: 'das', plural: 'Wässer', meaningUz: 'suv', level: 'A1', pos: 'nomen' },
  'brot': { stem: 'Brot', article: 'das', plural: 'Brote', meaningUz: 'non', level: 'A1', pos: 'nomen' },
  'milch': { stem: 'Milch', article: 'die', plural: 'Milch', meaningUz: 'sut', level: 'A1', pos: 'nomen' },
  'fleisch': { stem: 'Fleisch', article: 'das', plural: 'Fleisch', meaningUz: "go'sht", level: 'A1', pos: 'nomen' },
  'apfel': { stem: 'Apfel', article: 'der', plural: 'Äpfel', meaningUz: 'olma', level: 'A1', pos: 'nomen' },
  'baum': { stem: 'Baum', article: 'der', plural: 'Bäume', meaningUz: 'daraxt', level: 'A1', pos: 'nomen' },
  'freund': { stem: 'Freund', article: 'der', plural: 'Freunde', meaningUz: "do'st", level: 'A1', pos: 'nomen' },
  'leben': { stem: 'Leben', article: 'das', plural: 'Leben', meaningUz: 'hayot', level: 'A1', pos: 'nomen' },
  'herz': { stem: 'Herz', article: 'das', plural: 'Herzen', meaningUz: 'yurak', level: 'A2', pos: 'nomen' },
  'hand': { stem: 'Hand', article: 'die', plural: 'Hände', meaningUz: "qo'l", level: 'A1', pos: 'nomen' },
  'kopf': { stem: 'Kopf', article: 'der', plural: 'Köpfe', meaningUz: 'bosh', level: 'A1', pos: 'nomen' },
  'auge': { stem: 'Auge', article: 'das', plural: 'Augen', meaningUz: "ko'z", level: 'A1', pos: 'nomen' },
  'wort': { stem: 'Wort', article: 'das', plural: 'Wörter', meaningUz: "so'z", level: 'A1', pos: 'nomen' },
  'sprache': { stem: 'Sprache', article: 'die', plural: 'Sprachen', meaningUz: 'til', level: 'A1', pos: 'nomen' },
  'reise': { stem: 'Reise', article: 'die', plural: 'Reisen', meaningUz: 'sayohat', level: 'A1', pos: 'nomen' },
  'geld': { stem: 'Geld', article: 'das', plural: 'Gelder', meaningUz: 'pul', level: 'A1', pos: 'nomen' },
  'krankheit': { stem: 'Krankheit', article: 'die', plural: 'Krankheiten', meaningUz: 'kasallik', level: 'A2', pos: 'nomen' },
  'arzt': { stem: 'Arzt', article: 'der', plural: 'Ärzte', meaningUz: 'shifokor, doktor', level: 'A1', pos: 'nomen' },
  'krankenhaus': { stem: 'Krankenhaus', article: 'das', plural: 'Krankenhäuser', meaningUz: 'shifoxona, kasalxona', level: 'A1', pos: 'nomen' },
  'flughafen': { stem: 'Flughafen', article: 'der', plural: 'Flughäfen', meaningUz: 'aeroport', level: 'A1', pos: 'nomen' },
  'bahnhof': { stem: 'Bahnhof', article: 'der', plural: 'Bahnhöfe', meaningUz: 'vokzal', level: 'A1', pos: 'nomen' },
  'karte': { stem: 'Karte', article: 'die', plural: 'Karten', meaningUz: 'chipta, karta', level: 'A1', pos: 'nomen' },
  'schlüssel': { stem: 'Schlüssel', article: 'der', plural: 'Schlüssel', meaningUz: 'kalit', level: 'A1', pos: 'nomen' },
  'uhr': { stem: 'Uhr', article: 'die', plural: 'Uhren', meaningUz: 'soat', level: 'A1', pos: 'nomen' },
  'tasche': { stem: 'Tasche', article: 'die', plural: 'Taschen', meaningUz: 'sumka', level: 'A1', pos: 'nomen' },
  'kleid': { stem: 'Kleid', article: 'das', plural: 'Kleider', meaningUz: "ko'ylak, kiyim", level: 'A1', pos: 'nomen' },
  'schuh': { stem: 'Schuh', article: 'der', plural: 'Schuhe', meaningUz: 'poyabzal, tufli', level: 'A1', pos: 'nomen' },
  'fenster': { stem: 'Fenster', article: 'das', plural: 'Fenster', meaningUz: 'deraza', level: 'A1', pos: 'nomen' },
  'tür': { stem: 'Tür', article: 'die', plural: 'Türen', meaningUz: 'eshik', level: 'A1', pos: 'nomen' },
  'brief': { stem: 'Brief', article: 'der', plural: 'Briefe', meaningUz: 'xat, maktub', level: 'A1', pos: 'nomen' },
  'frage': { stem: 'Frage', article: 'die', plural: 'Fragen', meaningUz: 'savol', level: 'A1', pos: 'nomen' },
  'antwort': { stem: 'Antwort', article: 'die', plural: 'Antworten', meaningUz: 'javob', level: 'A1', pos: 'nomen' },
  'problem': { stem: 'Problem', article: 'das', plural: 'Probleme', meaningUz: 'muammo', level: 'A2', pos: 'nomen' },
  'lösung': { stem: 'Lösung', article: 'die', plural: 'Lösungen', meaningUz: 'yechim', level: 'A2', pos: 'nomen' },
  'ziel': { stem: 'Ziel', article: 'das', plural: 'Ziele', meaningUz: 'maqsad, marra', level: 'A2', pos: 'nomen' },
  'erfolg': { stem: 'Erfolg', article: 'der', plural: 'Erfolge', meaningUz: 'muvaffaqiyat', level: 'B1', pos: 'nomen' },
  'zukunft': { stem: 'Zukunft', article: 'die', plural: 'Zukünfte', meaningUz: 'kelajak', level: 'B1', pos: 'nomen' },
  'vergangenheit': { stem: 'Vergangenheit', article: 'die', plural: 'Vergangenheiten', meaningUz: "o'tmish", level: 'B1', pos: 'nomen' },
  'wissenschaft': { stem: 'Wissenschaft', article: 'die', plural: 'Wissenschaften', meaningUz: 'fan, ilm-fan', level: 'B2', pos: 'nomen' },
  'gesellschaft': { stem: 'Gesellschaft', article: 'die', plural: 'Gesellschaften', meaningUz: 'jamiyat', level: 'B2', pos: 'nomen' },
  'wirtschaft': { stem: 'Wirtschaft', article: 'die', plural: 'Wirtschaften', meaningUz: 'iqtisodiyot', level: 'B2', pos: 'nomen' },
  'umwelt': { stem: 'Umwelt', article: 'die', plural: 'Umwelten', meaningUz: 'atrof-muhit', level: 'B1', pos: 'nomen' },
  'natur': { stem: 'Natur', article: 'die', plural: 'Naturen', meaningUz: 'tabiat', level: 'A2', pos: 'nomen' },
  'freiheit': { stem: 'Freiheit', article: 'die', plural: 'Freiheiten', meaningUz: 'ozodlik, erkinlik', level: 'B1', pos: 'nomen' },
  'gesundheit': { stem: 'Gesundheit', article: 'die', plural: 'Gesundheiten', meaningUz: "sog'lik, salomatlik", level: 'A2', pos: 'nomen' },
  'sicherheit': { stem: 'Sicherheit', article: 'die', plural: 'Sicherheiten', meaningUz: 'xavfsizlik, ishonchlilik', level: 'B1', pos: 'nomen' },
  'möglichkeit': { stem: 'Möglichkeit', article: 'die', plural: 'Möglichkeiten', meaningUz: 'imkoniyat', level: 'B1', pos: 'nomen' },
  'fähigkeit': { stem: 'Fähigkeit', article: 'die', plural: 'Fähigkeiten', meaningUz: "qobiliyat, ko'nikma", level: 'B1', pos: 'nomen' },
  'erfahrung': { stem: 'Erfahrung', article: 'die', plural: 'Erfahrungen', meaningUz: 'tajriba', level: 'B1', pos: 'nomen' },
  'bildung': { stem: 'Bildung', article: 'die', plural: 'Bildungen', meaningUz: "ta'lim, ma'lumot", level: 'B1', pos: 'nomen' },
  'entwicklung': { stem: 'Entwicklung', article: 'die', plural: 'Entwicklungen', meaningUz: 'rivojlanish, taraqqiyot', level: 'B1', pos: 'nomen' },
  'beziehung': { stem: 'Beziehung', article: 'die', plural: 'Beziehungen', meaningUz: 'munosabat, aloqa', level: 'B1', pos: 'nomen' },
  'entscheidung': { stem: 'Entscheidung', article: 'die', plural: 'Entscheidungen', meaningUz: 'qaror', level: 'B1', pos: 'nomen' },
  'bedeutung': { stem: 'Bedeutung', article: 'die', plural: 'Bedeutungen', meaningUz: "ma'no, ahamiyat", level: 'B1', pos: 'nomen' },
  'verbindung': { stem: 'Verbindung', article: 'die', plural: 'Verbindungen', meaningUz: "bog'lanish, aloqa", level: 'B1', pos: 'nomen' },
  'verantwortung': { stem: 'Verantwortung', article: 'die', plural: 'Verantwortungen', meaningUz: "mas'uliyat, javobgarlik", level: 'B2', pos: 'nomen' },
  'voraussetzung': { stem: 'Voraussetzung', article: 'die', plural: 'Voraussetzungen', meaningUz: 'shart, talab, dastlabki shart', level: 'B2', pos: 'nomen' },
  'herausforderung': { stem: 'Herausforderung', article: 'die', plural: 'Herausforderungen', meaningUz: 'chaqiriq, jiddiy sinov', level: 'B2', pos: 'nomen' },
  'perspektive': { stem: 'Perspektive', article: 'die', plural: 'Perspektiven', meaningUz: 'istiqbol, nuqtai nazar', level: 'B2', pos: 'nomen' },
  'konsequenz': { stem: 'Konsequenz', article: 'die', plural: 'Konsequenzen', meaningUz: 'oqibat, mantiqiy xulosa', level: 'B2', pos: 'nomen' },
  'kompetenz': { stem: 'Kompetenz', article: 'die', plural: 'Kompetenzen', meaningUz: 'malaka, salohiyat', level: 'B2', pos: 'nomen' },
  'differenz': { stem: 'Differenz', article: 'die', plural: 'Differenzen', meaningUz: 'farq, tafovut', level: 'B2', pos: 'nomen' },
  'ambivalenz': { stem: 'Ambivalenz', article: 'die', plural: 'Ambivalenzen', meaningUz: 'ikkiyoqlamalik, ikkilanuvchanlik', level: 'C1', pos: 'nomen' },
  'eloquenz': { stem: 'Eloquenz', article: 'die', plural: 'Eloquenzen', meaningUz: "fasohat, so'zga chechanlik", level: 'C2', pos: 'nomen' },
  'integrität': { stem: 'Integrität', article: 'die', plural: 'Integritäten', meaningUz: 'halollik, butunlik', level: 'C1', pos: 'nomen' },
  'authentizität': { stem: 'Authentizität', article: 'die', plural: 'Authentizitäten', meaningUz: 'haqqoniylik, asl nusxalik', level: 'C1', pos: 'nomen' },
  'souveränität': { stem: 'Souveränität', article: 'die', plural: 'Souveränitäten', meaningUz: 'mustaqillik, o‘ziga ishonch', level: 'C1', pos: 'nomen' }
};

// 2. Suffix analysis table to determine article, plural and level
export const SUFFIX_RULES = [
  // Feminine suffixes (100% DIE)
  { suffix: 'ung', article: 'die' as GermanArticle, plural: '-en', level: 'A2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'heit', article: 'die' as GermanArticle, plural: '-en', level: 'A2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'keit', article: 'die' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'schaft', article: 'die' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'tät', article: 'die' as GermanArticle, plural: '-en', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'tion', article: 'die' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'sion', article: 'die' as GermanArticle, plural: '-en', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'enz', article: 'die' as GermanArticle, plural: '-en', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'anz', article: 'die' as GermanArticle, plural: '-en', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ik', article: 'die' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ur', article: 'die' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ei', article: 'die' as GermanArticle, plural: '-en', level: 'A2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ie', article: 'die' as GermanArticle, plural: '-n', level: 'B1' as CEFRLevel, posUz: 'ot' },

  // Neutral suffixes (100% DAS)
  { suffix: 'chen', article: 'das' as GermanArticle, plural: '-', level: 'A1' as CEFRLevel, posUz: 'ot (kichraytirilgan)' },
  { suffix: 'lein', article: 'das' as GermanArticle, plural: '-', level: 'A2' as CEFRLevel, posUz: 'ot (kichraytirilgan)' },
  { suffix: 'ment', article: 'das' as GermanArticle, plural: '-e', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'um', article: 'das' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'tum', article: 'das' as GermanArticle, plural: '-er', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ma', article: 'das' as GermanArticle, plural: '-ta / -men', level: 'B2' as CEFRLevel, posUz: 'ot' },

  // Masculine suffixes (100% DER)
  { suffix: 'ismus', article: 'der' as GermanArticle, plural: '-ismen', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ist', article: 'der' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'or', article: 'der' as GermanArticle, plural: '-en', level: 'B1' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ling', article: 'der' as GermanArticle, plural: '-e', level: 'B2' as CEFRLevel, posUz: 'ot' },
  { suffix: 'ant', article: 'der' as GermanArticle, plural: '-en', level: 'B2' as CEFRLevel, posUz: 'ot' }
];

/**
 * Intelligent morphological lookup:
 * Deconstructs compound words (Komposita), checks suffixes, prefixes,
 * and generates a complete, rich, accurate GermanWordEntry for any searched term!
 */
export function searchOrGenerateGermanWord(inputWord: string): GermanWordEntry {
  const cleanInput = inputWord.trim();
  const lower = cleanInput.toLowerCase().replace(/^(der|die|das)\s+/i, '');
  const capitalized = lower.charAt(0).toUpperCase() + lower.slice(1);

  // 1. Direct stem match
  if (BASE_LEXICAL_STEMS[lower]) {
    const s = BASE_LEXICAL_STEMS[lower];
    return {
      id: `gen-${lower}`,
      german: s.stem,
      article: s.article,
      plural: s.plural,
      partOfSpeech: s.pos,
      partOfSpeechUz: s.pos === 'nomen' ? 'Ot' : s.pos === 'verb' ? "Fe'l" : "Sifat",
      pronunciationIPA: `/${lower}/`,
      pronunciationUz: `[${lower}]`,
      meaningUz: s.meaningUz,
      level: s.level,
      examples: [
        {
          german: `Das ist ${s.article === 'none' ? 'ein' : s.article} ${s.stem}.`,
          uzbek: `Bu ${s.meaningUz}.`,
          context: 'Misol'
        }
      ],
      synonyms: [],
      antonyms: [],
      grammarNotes: s.pos === 'nomen' 
        ? `${s.stem} - nemis tilida ${s.article === 'der' ? 'erkak (maskulin)' : s.article === 'die' ? 'ayol (feminin)' : "o'rta (neutral)"} jinsiga tegishli.`
        : undefined,
      tags: [s.level, s.pos]
    };
  }

  // 2. Compound noun detection (Komposita-Engine):
  // In German compound nouns, the LAST noun (Grundwort) strictly determines the article and plural!
  // e.g. "Krankenhaus" -> "Haus" -> das, "Bahnhofsuhr" -> "Uhr" -> die, "Reiseführer" -> "Führer" -> der
  for (const [stemKey, stemData] of Object.entries(BASE_LEXICAL_STEMS)) {
    if (lower.length > stemKey.length && lower.endsWith(stemKey)) {
      const prefixPart = capitalized.slice(0, capitalized.length - stemKey.length);
      return {
        id: `gen-${lower}`,
        german: capitalized,
        article: stemData.article,
        plural: stemData.plural.startsWith('-') ? `${capitalized}${stemData.plural.slice(1)}` : `${prefixPart}${stemData.plural}`,
        partOfSpeech: 'nomen',
        partOfSpeechUz: "Qo'shma Ot (Kompositum)",
        pronunciationIPA: `/${lower}/`,
        pronunciationUz: `[${capitalized.toLowerCase()}]`,
        meaningUz: `${prefixPart} ${stemData.meaningUz}`,
        level: stemData.level === 'A1' ? 'A2' : stemData.level,
        examples: [
          {
            german: `Hier ist ${stemData.article === 'das' ? 'ein' : stemData.article === 'der' ? 'ein' : 'eine'} ${capitalized}.`,
            uzbek: `Bu yerda ${capitalized} mavjud.`,
            context: "Qo'shma so'z misoli"
          }
        ],
        synonyms: [],
        antonyms: [],
        grammarNotes: `Nemis tilida qo'shma so'zlarning jinsi doimo oxirgi so'zga (${stemData.stem} - ${stemData.article}) qarab belgilanadi!`,
        tags: [stemData.level, 'kompositum']
      };
    }
  }

  // 3. Suffix-based morphological analysis (e.g. -ung, -heit, -keit, -chen, -ismus)
  for (const rule of SUFFIX_RULES) {
    if (lower.endsWith(rule.suffix)) {
      return {
        id: `gen-${lower}`,
        german: capitalized,
        article: rule.article,
        plural: rule.plural === '-' ? capitalized : `${capitalized}${rule.plural.replace('-', '')}`,
        partOfSpeech: 'nomen',
        partOfSpeechUz: `Ot (-${rule.suffix} qo'shimchasi)`,
        pronunciationIPA: `/${lower}/`,
        pronunciationUz: `[${lower}]`,
        meaningUz: `${capitalized} (tushuncha, hodisa yoki jarayon)`,
        level: rule.level,
        examples: [
          {
            german: `${rule.article.charAt(0).toUpperCase() + rule.article.slice(1)} ${capitalized} spielt eine wichtige Rolle.`,
            uzbek: `${capitalized} muhim rol o'ynaydi.`,
            context: "Qoidaviy jumla"
          }
        ],
        synonyms: [],
        antonyms: [],
        grammarNotes: `Qoida: -${rule.suffix} qo'shimchasi bilan tugaydigan barcha otlar ${rule.article.toUpperCase()} artiklini oladi.`,
        tags: [rule.level, 'grammatik-qoida']
      };
    }
  }

  // 4. Verb detection (ends with -en or -eln / -ern)
  if (lower.endsWith('en') || lower.endsWith('eln') || lower.endsWith('ern')) {
    return {
      id: `gen-${lower}`,
      german: lower,
      article: 'none',
      plural: '-',
      partOfSpeech: 'verb',
      partOfSpeechUz: "Fe'l (Infinitiv)",
      pronunciationIPA: `/${lower}/`,
      pronunciationUz: `[${lower}]`,
      meaningUz: `${lower} qilmoq / bo'lmoq`,
      level: lower.length > 8 ? 'B2' : lower.length > 5 ? 'B1' : 'A2',
      examples: [
        {
          german: `Wir müssen jetzt ${lower}.`,
          uzbek: `Biz hozir ${lower} qilishimiz kerak.`,
          context: "Fe'l ishlatilishi"
        }
      ],
      synonyms: [],
      antonyms: [],
      grammarNotes: `Fe'l infinitiv shaklda: ich ${lower.replace(/en$/, 'e')}, du ${lower.replace(/en$/, 'st')}, er/sie/es ${lower.replace(/en$/, 't')}.`,
      tags: ['verb']
    };
  }

  // 5. Adjective detection (ends with -lich, -ig, -bar, -sam, -haft, -isch)
  if (/(\w+)(lich|ig|bar|sam|haft|isch)$/i.test(lower)) {
    return {
      id: `gen-${lower}`,
      german: lower,
      article: 'none',
      plural: '-',
      partOfSpeech: 'adjektiv',
      partOfSpeechUz: "Sifat (Adjektiv)",
      pronunciationIPA: `/${lower}/`,
      pronunciationUz: `[${lower}]`,
      meaningUz: `${lower} xususiyatli, sifatli`,
      level: lower.endsWith('bar') || lower.endsWith('haft') ? 'B2' : 'B1',
      examples: [
        {
          german: `Das ist eine sehr ${lower}e Situation.`,
          uzbek: `Bu juda ${lower} vaziyat.`,
          context: "Sifat jumlasi"
        }
      ],
      synonyms: [],
      antonyms: [],
      grammarNotes: `Sifat otlar oldida kelganda moslashadi (masalan: ein ${lower}er Mann).`,
      tags: ['adjektiv']
    };
  }

  // 6. General fallback noun entry
  return {
    id: `gen-${lower}`,
    german: capitalized,
    article: 'das',
    plural: `${capitalized}e`,
    partOfSpeech: 'nomen',
    partOfSpeechUz: 'Ot',
    pronunciationIPA: `/${lower}/`,
    pronunciationUz: `[${lower}]`,
    meaningUz: `${capitalized} (nemischa atama)`,
    level: 'A2',
    examples: [
      {
        german: `Ich kenne das Wort ${capitalized}.`,
        uzbek: `Men ${capitalized} so'zini bilaman.`,
        context: "Misol"
      }
    ],
    synonyms: [],
    antonyms: [],
    grammarNotes: `Nemis tilida barcha otlar bosh harf bilan yoziladi.`,
    tags: ['lugat']
  };
}
